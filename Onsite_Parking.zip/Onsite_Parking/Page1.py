# -*- coding: utf-8 -*-
"""
Created on Thu Mar 14 11:29:37 2024

@author: Raxzyer
"""

from PyQt5 import QtCore, QtGui, QtWidgets
import sys
from PyQt5.QtWidgets import QApplication, QMainWindow,QTableWidget,  QGroupBox,QTableWidgetItem ,QVBoxLayout, QWidget,QLabel  
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPixmap,QImage
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1125, 650)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        
        
        self.groupBox = QtWidgets.QGroupBox(self.centralwidget)        
        self.groupBox.setGeometry(QtCore.QRect(0, 0, 1000, 650))
        self.groupBox.setStyleSheet("QGroupBox { border: none; }")
        self.backgroundLabel = QtWidgets.QLabel(self.groupBox)
        plt.rcParams['xtick.direction'] = 'in'
        self.figure = Figure((600, 90))
        self.canvas = FigureCanvas(self.figure)
        self.layout = QVBoxLayout()
        self.layout.addWidget(self.canvas)
        self.groupBox.setLayout(self.layout)   
        self.ax = self.figure.add_subplot(111)
        # self.img = plt.imread("C:/Users/Raxzyer/Desktop/微信图片_20240317113148.jpg")
        # 然后在现有的代码中添加以下部分以显示背景图片
        # self.ax.imshow(img,extent = [0, 5100, 0, 5600])  # 设置extent和aspect参数以调整图片位置和缩放
        # 去掉轴和轴标签
        self.ax.axis('off')
        self.figure.patch.set_facecolor('lightblue')
      
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_2.setGeometry(QtCore.QRect(1000, 300, 111, 31))
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(1000, 240, 111, 31))
        self.pushButton.setObjectName("pushButton")
        self.pushButton_3 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_3.setGeometry(QtCore.QRect(1000, 360, 111, 31))
        self.pushButton_3.setObjectName("pushButton_3")
        
        "=========================================================="
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusBar().showMessage('Ready')  # 在状态栏上显示消息
        self.setWindowTitle('Status Bar Example')
        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "仿真演示"))
        self.pushButton_2.setText(_translate("MainWindow", "暂停仿真"))
        self.pushButton.setText(_translate("MainWindow", "仿真开始"))
        self.pushButton_3.setText(_translate("MainWindow", "重置仿真"))
        # self.groupBox.setTitle(_translate("MainWindow", "GroupBox"))

    
class MyMainWindow(QMainWindow, Ui_MainWindow):
    def __init__(self, parent=None):
        super(MyMainWindow, self).__init__(parent)
        self.setupUi(self)
        # self.plot_on_label() 
        
    def closeEvent(self, event):
    # 在窗口关闭时结束应用程序的运行
        app.exit()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MyMainWindow()
    window.show()
    
    sys.exit(app.exec_())