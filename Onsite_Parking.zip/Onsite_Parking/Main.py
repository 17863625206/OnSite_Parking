# -*- coding: utf-8 -*-
"""
Created on Wed Mar 20 15:42:19 2024

@author: Raxzyer
"""



import sys
from PyQt5 import  QtWidgets
import Page1 as P1
import input.make_map as mp
from planner.hybridastar import planner as planner
from input import make_car
import matplotlib.pyplot as plt
from utils import drawcar as tools
from utils import reeds_shepp as rs
import math
from PyQt5.QtWidgets import QApplication
import threading
import json

class platform():    
    def __init__(self):
        self.page1=Main()

    def start(self):
        self.page1.setupUi(MainWindow)
        self.page1.pushButton.clicked.connect(self.page1.start_simulation)
        self.page1.pushButton_2.clicked.connect(self.page1.pause_simulation)
        self.page1.pushButton_3.clicked.connect(self.page1.restart_simulation)


class Main(QtWidgets.QMainWindow,P1.Ui_MainWindow):
    def __init__(self, parent=None):
        super(Main, self).__init__(parent)
        self.map_path = 'input/A01.json'
        self.C = make_car.C
        park = '13'
        self.ox, self.oy, self.sp , self.gp = mp.make_map(self.map_path)
        self.sx, self.sy, self.syaw0 = self.sp['x'], self.sp['y'], self.sp['yaw']
        self.gx, self.gy, self.gyaw0 = self.gp[park]['x_end'], self.gp[park]['y_end'], self.gp[park]['yaw']
        self.path = planner.hybrid_astar_planning(self.sx, self.sy,    self.syaw0, self.gx, 
                                                  self.gy, self.gyaw0, self.ox,    self.oy, 
                                                  self.C.XY_RESO,      self.C.YAW_RESO)
        self.x = self.path.x
        self.y = self.path.y
        self.yaw = self.path.yaw
        self.direction = self.path.direction
        
        self.background_img = plt.imread(self.map_path.replace('/', '/').replace('.json', '.jpg'))
        self.k = 0    
        
        # 算法测试结果保存
        if not self.path:
            print("Searching failed!")
            return
        output_dit={
            "output_x": self.path.x,
            "output_y": self.path.y,
            "output_yaw": self.path.yaw,
            "output_dir": self.path.direction,
        }
        with open("output/result.json", "w") as file:
            json.dump(output_dit, file)   

    def start_simulation(self):
        # 仿真回放 
        self.simu = True
        self.sim_thread = threading.Thread(target=self.replay())
        self.sim_thread.start()

    def pause_simulation(self):
        self.simu = False
        self.replay()

    def replay(self):
        self.ax.imshow(self.background_img,extent = [min(self.ox), max(self.ox), min(self.oy), max(self.oy)],aspect = 'auto')
        # 设置自动调整宽高比例)  # 设置extent和aspect参数以调整图片位置和缩放
        ax = self.ax 
        while self.k < len(self.x) and self.simu:
            # ax.lines.clear()
            # ax.plot(self.ox, self.oy, ",k")
            ax.plot(self.x, self.y, linewidth=0.5, color='b',linestyle='--')
            if self.k < len(self.x) - 2:
                dy = (self.yaw[self.k + 1] - self.yaw[self.k]) / self.C.MOVE_STEP
                steer = rs.pi_2_pi(math.atan(-self.C.WB * dy / self.direction[self.k]))
            else:
                steer = 0.0
            tools.draw_car(ax,self.gx, self.gy, self.gyaw0, 0.0,color = 'dimgray')
            tools.draw_car(ax,self.x[self.k], self.y[self.k], self.yaw[self.k], steer)
            self.k = self.k + 1
            self.canvas.draw()  # 重新绘制并刷新画布
            QApplication.processEvents()  # 更新界面
        if self.k == len(self.x):
            print("仿真结束")
      
        
    def restart_simulation(self):
        self.k = 0
        self.simu = True
        self.sim_thread = threading.Thread(target=self.replay())
        self.sim_thread.start()
   
if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    platform = platform()
    MainWindow = QtWidgets.QMainWindow()
    platform.start()
    MainWindow.show()
    sys.exit(app.exec_())

    