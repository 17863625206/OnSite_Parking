def getpath(path):
    x = path.x
    y = path.y
    yaw = path.yaw
    direction = path.direction
    for i in range(len(x)):
        print(x[i],y[i],yaw[i],direction[i])

        