import math
import time
import numpy as np
import matplotlib.pyplot as plt
import input.make_map as mp
from planner.hybridastar import planner as planner
from utils import drawcar as tools
import hybridastar.reeds_shepp as rs
from input import make_car
import utils.calscore as calscore
C=make_car.C
def main():

    sx, sy, syaw0 = 500, 850, np.deg2rad(90.0)
    gx, gy, gyaw0 = 3900, 4300, np.deg2rad(245.0)
    map_path = '../input/test_map.json'
    ox, oy = mp.make_map(map_path)
    print("Running......")
    t0 = time.time()
    path = planner.hybrid_astar_planning(sx, sy, syaw0, gx, gy, gyaw0, ox, oy, C.XY_RESO, C.YAW_RESO)
    if not path:
        print("Searching failed!")
        return
    x = path.x
    y = path.y
    yaw = path.yaw
    direction = path.direction
    plt.rcParams['xtick.direction'] = 'in'
    plt.cla()
    plt.plot(ox, oy, ",k")
    plt.tick_params(axis='x', direction='in', top=True,bottom=False,labelbottom=False, labeltop=True)
    plt.axis("equal")
    tools.draw_car(gx, gy, gyaw0, 0.0, 'dimgray')
    tools.draw_car(sx, gy, gyaw0, 0.0, 'dimgray')
    for k in range(len(x)):
        plt.cla()
        plt.plot(ox, oy, ",k")
        plt.plot(x, y, linewidth=1.5, color='r')

        if k < len(x) - 2:
            dy = (yaw[k + 1] - yaw[k]) / C.MOVE_STEP
            steer = rs.pi_2_pi(math.atan(-C.WB * dy / direction[k]))
        else:
            steer = 0.0
        tools.draw_car(gx, gy, gyaw0, 0.0, 'dimgray')
        tools.draw_car(x[k], y[k], yaw[k], steer)
        plt.title("Simulation Result",loc='left',fontweight="heavy")
        plt.axis("equal")
        plt.pause(0.0001)
    t1 = time.time()
    print("start score ..............................................")
    t = t1 - t0
    steer, direc = planner.calc_motion_set()
    tar_park = [gx, gy, gyaw0]
    total_score,score = calscore.calculate_scores(path, tar_park, t, direc, steer,ox,oy)
    print(f"total_score:{total_score}")
    table_data = [['safety_score', 'efficiency_score', 'comfort_score','total_score'], [score[0], score[1], score[2],total_score]]
    table=plt.table(cellText=table_data, loc='bottom', cellLoc='center')
    table.scale(1, 1.5)  # 调整表格大小
    table.auto_set_font_size(False)
    table.set_fontsize(9)
    plt.show()
    print("Done!")

if __name__ == '__main__':
    main()
