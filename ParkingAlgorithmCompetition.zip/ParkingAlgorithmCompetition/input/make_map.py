import json


def make_map(map_path):


    with open(map_path,'r',encoding='UTF-8') as f:
        map=json.load(f)
    ox = map['obstacles']['ox']
    oy = map['obstacles']['oy']
    return ox, oy