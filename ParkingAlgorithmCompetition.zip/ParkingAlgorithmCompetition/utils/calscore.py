import math
from shapely.geometry import Polygon
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np
import input.make_map as mp


def calculate_scores(path, tar_park,time,direc,steer,ox,oy):

    safety_s = safety_score(path, tar_park,ox,oy)
    efficiency_s = efficiency_score(path, tar_park,time,direc)
    comfort_s = comfort_score(steer)
    total_score = safety_s + efficiency_s + comfort_s
    score = [safety_s,efficiency_s,comfort_s]
    return total_score,score


# 安全得分
def safety_score(path, tar_park,ox,oy):
    # 如果相撞
    obstacle_polygons = []
    for i in range(len(ox)):
        p = Point(ox[i], oy[i])
        obstacle_polygons.append(p)

    is_collision = check_collision(path,obstacle_polygons )
    if is_collision:
        print(f"collision!,safety_score:0")
        return 0
    print(" NO Collision")
    # 停车位置扣分，车辆中心与车位中心位置偏移量，每相差10cm,扣两分
    distance = math.sqrt((tar_park[0] - path.x[-1]) ** 2 + (tar_park[1] - path.y[-1]) ** 2)
    if distance > 2000:
        print("任务未完成")
        return 0
    print(f"distance:{distance}")
    parking_position_score =distance // 10 * 2
    # 停车姿态扣分,车辆中心线与车位中心线之间夹角，每相差1,扣1分
    parking_posture_score = abs(np.rad2deg(tar_park[2])%360-np.rad2deg(path.yaw[-1])%360)
    print(np.rad2deg(tar_park[2]))
    print(np.rad2deg(path.yaw[-1]))
    score = 50 - parking_position_score - parking_posture_score
    print(f"parking_position_score:{25-parking_position_score}")
    print(f"parking_posture_score:{25-parking_posture_score}")
    print(f"safety_score:{score}")
    score = 0 if score <= 0 else score
    return score

# 效率得分
def efficiency_score(path, tar_park,time,direc):
    # 判断是否完成
    distance = math.sqrt((tar_park[0] - path.x[-1]) ** 2 + (tar_park[1] - path.y[-1]) ** 2)
    if distance > 2000:
        print("任务未完成")
        return 0
    # 任务耗时得分：任务限时两分钟？，每多10s扣一分
    t = time / 5
    t_score = 10 - abs(t - 120) % 10
    # 换挡次数得分
    Shift_frequency = 0
    for i in range(len(direc)-1):
        if direc[i] * direc[i + 1] < 0:
            Shift_frequency += 1
    f_score = 10 - (Shift_frequency - 3) * 2
    f_score = f_score if f_score > 0 else 0
    print(f"time:{time}")
    print(f"Shift_frequency:{Shift_frequency}")
    print(f"efficiency_score:{10 + t_score + f_score}")
    return 10 + t_score + f_score


# 舒适性得分:加速度与角速度在阈值范围内的占比 * 总分
def comfort_score(steer):
    # # 计算纵向加速度大于 1 m/s**2 的总时长占比
    # t_acc_num = 0
    # for p in path:
    #     if abs(p.acc) > 1:
    #         t_acc_num += 1
    # ratio_acc = t_acc_num / len(path)
    ratio_acc = 0.002
    # 计算横向加速度大于 30  的总时长占比
    t_steer_num = 0
    for s in steer:
        if abs(s) > 30:
            t_steer_num += 1
    ratio_steer = t_steer_num / len(steer)
    ratio = (10*(1-ratio_acc))+(10*(1-ratio_steer))
    print(f"comfort_score:{ratio}")
    return ratio


# 检测是否发生碰撞
def check_collision(path, obstacle_polygons):
    x = path.x
    y = path.y
    yaw = path.yaw
    for point in obstacle_polygons:
        for i in range(len(x)):
            r = draw_rectangle(450,300,x[i], y[i],np.rad2deg(yaw[i]))
            quad = [(r[0], r[1]), (r[2], r[3]), (r[4], r[5]), (r[6], r[7])]
            p=(point.x,point.y)
            if is_point_in_quad(p,quad):
                print(point.x,point.y,x[i], y[i], 300, 450, np.rad2deg(yaw[i]))
                return True
    return False



# 已知长、宽、中心点、角度、绘制一个矩形
def draw_rectangle(length, width, center_x,center_y,direction):
    # 计算矩形的四个角点坐标
    angle = math.radians(direction)
    dx = length / 2 * math.cos(angle)
    dy = length / 2 * math.sin(angle)
    x1 = center_x - dx - width / 2 * math.sin(angle)
    y1 = center_y - dy + width / 2 * math.cos(angle)
    x2 = center_x - dx + width / 2 * math.sin(angle)
    y2 = center_y - dy - width / 2 * math.cos(angle)
    x3 = center_x + dx + width / 2 * math.sin(angle)
    y3 = center_y + dy - width / 2 * math.cos(angle)
    x4 = center_x + dx - width / 2 * math.sin(angle)
    y4 = center_y + dy + width / 2 * math.cos(angle)

    rectangle = [x1,y1,x2,y2,x3,y3,x4,y4]

    return rectangle

class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

def is_point_in_quad(point, quad):
    x, y = point
    count = 0
    for i in range(4):
        x1, y1 = quad[i]
        x2, y2 = quad[(i + 1) % 4]
        if ((y1 <= y < y2) or (y2 <= y < y1)) and (x < (x2 - x1) * (y - y1) / (y2 - y1) + x1):
            count += 1
    return count % 2 == 1


