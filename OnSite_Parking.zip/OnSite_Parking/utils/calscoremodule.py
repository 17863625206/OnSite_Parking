import json
import tkinter as tk
from tkinter import filedialog
import math
import numpy as np
from shapely import Polygon


def select_file1():
    file_path = filedialog.askopenfilename()
    file1_entry.delete(0, tk.END)
    file1_entry.insert(tk.END, file_path)
    global file_path1
    file_path1 = file_path
def select_file2():
    file_path = filedialog.askopenfilename()
    file2_entry.delete(0, tk.END)
    file2_entry.insert(tk.END, file_path)
    global file_path2
    file_path2 = file_path
def calculate_score():
    with open(file_path1,'r',encoding='UTF-8') as f1:
        map1=json.load(f1)
    ox = map1['obstacles']['ox']
    oy = map1['obstacles']['oy']
    gp = map1['parking_sport']
    gx, gy, gyaw = gp['3']['x_end'], gp['3']['y_end'], gp['3']['yaw']
    gpos, gdis = gp['3']['pos'],gp['3']['dis']
    with open(file_path2,'r',encoding='UTF-8') as f2:
        map2=json.load(f2)
    p_x = map2["output_x"]
    p_y = map2["output_y"]
    p_yaw = map2["output_yaw"]
    p_direction = map2["output_dir"]

    finish,score_p,score_e, score = calculate_scores(p_x, p_y, p_yaw, p_direction, gx, gy, gyaw, gpos, gdis,ox, oy)
    # 设置表格
    table = tk.Frame(window)
    table.pack()
    table.place(x=30, y=210)
    # 设置表格的内容
    tscore = [["是否完成", "姿态位置得分", "效率得分", "总分"], [finish, score_p, score_e, score]]
    # 设置表格的布局
    for i in range(2):
        for j in range(4):
            cell = tk.Label(table, text=f"{tscore[i][j]}")
            cell.grid(row=i, column=j, padx=5, pady=5)
def reset():
    file1_entry.delete(0, tk.END)
    file2_entry.delete(0, tk.END)
    score_label.config(text="Score: ")

# 打分算法
def calculate_scores(px, py, pyaw, pdirec, gx, gy, gyaw, gp, gdis, ox, oy):
    print(f'aaa{is_finish(px, py, pyaw, gp, ox, oy)}')
    if not is_finish(px, py, pyaw, gp, ox, oy):
        return "N", 0, 0, 0
    score_p = pos_score(px, py, pyaw, gx, gy, gyaw)
    print(score_p)
    score_e = efficiency_score(px, py, pdirec, gdis)
    print(score_e)
    return "Y", score_p, score_e, round(score_p+score_e, 2)

# 是否完成
def is_finish(px, py, pyaw, gp, ox, oy):
    obstacle_polygons = []
    for i in range(len(ox)):
        p = Point(ox[i], oy[i])
        obstacle_polygons.append(p)
    is_collision = check_collision(px, py, pyaw, obstacle_polygons)
    p = draw_rectangle(450, 300, px[-1], py[-1], np.rad2deg(pyaw[-1]))
    polygon1 = Polygon([(p[0], p[1]), (p[2], p[3]), (p[4], p[5]), (p[6], p[7])])
    polygon2 = Polygon([(gp[0], gp[1]), (gp[2], gp[3]), (gp[4], gp[5]), (gp[6], gp[7])])
    print([(p[0], p[1]), (p[2], p[3]), (p[4], p[5]), (p[6], p[7])])
    print([(gp[0], gp[1]), (gp[2], gp[3]), (gp[4], gp[5]), (gp[6], gp[7])])
    is_inside = polygon2.contains(polygon1)
    print(f"is_inside {is_inside}")
    print(f"is_collision{is_collision}")
    return is_inside and (not is_collision)
# 位置姿态扣分
def pos_score(px, py, pyaw, gx, gy, gyaw):
    # 停车位置扣分，车辆中心与车位中心位置偏移量，每相差10cm,扣两分
    distance = math.sqrt((gx - px[-1]) ** 2 + (gy - py[-1]) ** 2)
    print(f"distance:{distance}")
    position_score = 20 - (distance // 5 * 2)
    position_score = position_score if position_score > 0 else 0
    # 停车姿态扣分,车辆中心线与车位中心线之间夹角，每相差1,扣1分
    posture_score = 20-(abs(np.rad2deg(gyaw) % 360-np.rad2deg(pyaw[-1]) % 360) * 4)
    posture_score = posture_score if posture_score > 0 else 0
    score = position_score + posture_score
    print(f"pos_score:{score}")

    return round(score, 2)

# 效率得分
def efficiency_score(px, py, pdirec, gdis):
    # 任务耗时得分：任务限时两分钟？，每多10s扣一分
    spend_dis=0
    for i in range(len(px)-1):
        d = math.sqrt((px[i+1] - px[i]) ** 2 + (py[i+1] - py[i]) ** 2)
        spend_dis = spend_dis + d

    time_score= gdis/spend_dis * 20
    time_score = 30 if time_score > 30 else time_score
    # 换挡次数得分
    Shift_frequency = 0
    for i in range(len(pdirec)-1):
        if pdirec[i] * pdirec[i + 1] < 0:
            Shift_frequency += 1
    f_score = 30 - ((Shift_frequency - 1) * 2)
    f_score = f_score if f_score > 0 else 0

    return round(time_score + f_score,2)

# 检测是否发生碰撞
def check_collision(px, py, pyaw, obstacle_polygons):
    for point in obstacle_polygons:
        for i in range(len(px)):
            r = draw_rectangle(450,300,px[i], py[i],np.rad2deg(pyaw[i]))
            quad = [(r[0], r[1]), (r[2], r[3]), (r[4], r[5]), (r[6], r[7])]
            p=(point.x,point.y)
            if is_point_in_quad(p,quad):
                print(point.x,point.y,px[i], py[i], 300, 450, np.rad2deg(pyaw[i]))
                return True
    return False

# 已知长、宽、中心点、角度、绘制一个矩形
def draw_rectangle(length, width, center_x, center_y, direction):
    # 计算矩形的四个角点坐标
    angle = math.radians(direction)
    dx = length / 2 * math.cos(angle)
    dy = length / 2 * math.sin(angle)
    x1 = center_x - dx - width / 2 * math.sin(angle)
    y1 = center_y - dy + width / 2 * math.cos(angle)
    x2 = center_x - dx + width / 2 * math.sin(angle)
    y2 = center_y - dy - width / 2 * math.cos(angle)
    x3 = center_x + dx + width / 2 * math.sin(angle)
    y3 = center_y + dy - width / 2 * math.cos(angle)
    x4 = center_x + dx - width / 2 * math.sin(angle)
    y4 = center_y + dy + width / 2 * math.cos(angle)
    rectangle = [x1,y1,x2,y2,x3,y3,x4,y4]
    return rectangle

class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

def is_point_in_quad(point, quad):
    x, y = point
    count = 0
    for i in range(4):
        x1, y1 = quad[i]
        x2, y2 = quad[(i + 1) % 4]
        if ((y1 <= y < y2) or (y2 <= y < y1)) and (x < (x2 - x1) * (y - y1) / (y2 - y1) + x1):
            count += 1
    return count % 2 == 1

# 创建主窗口
window = tk.Tk()
window.title("打分工具")
window.geometry("450x350")  # 设置窗口大小

# 文件选择按钮和文本框
file1_button = tk.Button(window, text="输入测试场景", command=select_file1)
file1_entry = tk.Entry(window)
file1_button.place(x=30, y=50)
file1_entry.place(x=160, y=50)

file2_button = tk.Button(window, text="输入算法轨迹", command=select_file2)
file2_entry = tk.Entry(window)
file2_button.place(x=30, y=100)
file2_entry.place(x=160, y=100)

# 得分按钮
score_button = tk.Button(window, text="计算得分", command=calculate_score)
score_button.place(x=70, y=160)

# 重置按钮
reset_button = tk.Button(window, text="重置文件", command=reset)
reset_button.place(x=240, y=160)

# 得分标签
score_label = tk.Label(window, text="打分时间可能较长，请耐心等待!")
score_label.pack()

# 启动主循环
window.mainloop()
