"""
算法结果回放

"""
import json
import math
import matplotlib.pyplot as plt
import input.make_map as mp
from utils import drawcar as tools, reeds_shepp as rs
from input import make_car

def replay(map_scene,output_result):
    C = make_car.C
    ox, oy,sp,gp = mp.make_map(map_scene)
    sx, sy, syaw0 = sp['x'], sp['y'], sp['yaw']
    gx, gy, gyaw0 = gp['3']['x_end'], gp['3']['y_end'], gp['3']['yaw']
    with open(output_result,'r',encoding='UTF-8') as f:
        result=json.load(f)
    x = result['output_x']
    y = result['output_y']
    yaw = result['output_yaw']
    direction = result['output_dir']
    # x = path.x
    # y = path.y
    # yaw = path.yaw
    # direction = path.direction
    plt.rcParams['xtick.direction'] = 'in'
    plt.cla()
    plt.plot(ox, oy, ",k")
    plt.tick_params(axis='x', direction='in', top=True, bottom=False, labelbottom=False, labeltop=True)
    plt.axis("equal")
    tools.draw_car(gx, gy, gyaw0, 0.0, 'dimgray')
    tools.draw_car(sx, gy, gyaw0, 0.0, 'dimgray')
    for k in range(len(x)):
        plt.cla()
        plt.plot(ox, oy, ",k")
        plt.plot(x, y, linewidth=1.5, color='r')
        if k < len(x) - 2:
            dy = (yaw[k + 1] - yaw[k]) / C.MOVE_STEP
            steer = rs.pi_2_pi(math.atan(-C.WB * dy / direction[k]))
        else:
            steer = 0.0
        tools.draw_car(gx, gy, gyaw0, 0.0, 'dimgray')
        tools.draw_car(x[k], y[k], yaw[k], steer)
        plt.title("Simulation Result", loc='left', fontweight="heavy")
        plt.axis("equal")
        plt.pause(0.0001)
    print("仿真结束!")
    plt.show()
