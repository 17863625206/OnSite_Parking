import json
import input.make_map as mp
from input import make_car
from utils import replay
from utils import map_display as mdp
def main():
    # 请在此输入input文件夹下场景文件
    map_path = ''
    # mdp.map_display(map_path) #  仅绘制地图
    ox, oy,sp,gp = mp.make_map(map_path)
    sx, sy, syaw0 = sp['x'], sp['y'], sp['yaw']
    C = make_car.C
    # 遍历所有停车位
    for i in range(1,len(gp)+1):
        gx, gy, gyaw0 = gp[str(i)]['x_end'], gp[str(i)]['y_end'], gp[str(i)]['yaw']
        # 请在此调用planer文件夹下的规控算法
        path = ''
        # 算法测试结果保存
        if not path:
            print("Searching failed!")
            return
        output_dit={
            "output_x": path.x,
            "output_y": path.y,
            "output_yaw": path.yaw,
            "output_dir": path.direction,
        }
        with open(f"../output/result{str(i)}.json", "w") as file:
            json.dump(output_dit, file)

    # 仿真回放
    # result_path = '../output/result1.json'
    # replay.replay(map_path, result_path)

if __name__ == '__main__':
    main()